import sqlite3

def crear_bd():
    conn = sqlite3.connect('db/users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            usuario TEXT PRIMARY KEY,
            contrasena TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def registrar_usuario(nombre, password):
    conn = sqlite3.connect("db/users.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO usuarios VALUES (?, ?)", (nombre, password))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False

def validar_usuario(nombre, password):
    conn = sqlite3.connect("db/users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE usuario=? AND contrasena=?", (nombre, password))
    return cursor.fetchone() is not None

def crear_usuario_inicial():
    crear_bd()
    registrar_usuario('cama', '1234')
    registrar_usuario('si', '1234')  # Añade este usuario inicial

# Ejecuta esta función una sola vez al inicio
crear_usuario_inicial()
